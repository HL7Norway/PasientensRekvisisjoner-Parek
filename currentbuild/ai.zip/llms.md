# hl7.fhir.no.ParekIG#0.1.7: Pasientens rekvisisjoner

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Healthcare Person Id Type CS](CodeSystem-healthcare-person-id-type-cs.md)
* [Organization Id Type CS](CodeSystem-organization-id-type-cs.md)
* [Person Public Id Type CS](CodeSystem-person-public-id-type-cs.md)

### ValueSets

* [Person Id Type VS](ValueSet-healthcare-person-id-type-vs.md)
* [Organization Id Type VS](ValueSet-organization-id-type-vs.md)
* [Public Id Type VS](ValueSet-person-public-id-type-vs.md)
* [Specimen Type VS](ValueSet-specimen-type-vs.md)

### Resource Profiles

* [ParekCollector](StructureDefinition-parek-collector-pr.md)
* [Parek Device](StructureDefinition-parek-device.md)
* [ParekPractitionerRole](StructureDefinition-parek-practitioner-role.md)
* [ParekRequester](StructureDefinition-parek-requester-pr.md)
* [ParekServiceRequest](StructureDefinition-parek-service-request.md)
* [ParekSpecimen](StructureDefinition-parek-specimen.md)

### ImplementationGuides

* [Pasientens rekvisisjoner](index.md)

### NamingSystems

* [RequesterDefinedUuid](NamingSystem-RequesterDefinedUuid.md)

### Examples

* [ADevice (Device)](Device-ADevice.md)
* [ACollector (PractitionerRole)](PractitionerRole-ACollector.md)
* [ARequester (PractitionerRole)](PractitionerRole-ARequester.md)
* [ARequest (ServiceRequest)](ServiceRequest-ARequest.md)
* [ASpecimen (Specimen)](Specimen-ASpecimen.md)
