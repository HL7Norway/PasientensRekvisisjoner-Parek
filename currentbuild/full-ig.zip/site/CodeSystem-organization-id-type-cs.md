# Organization Id Type CS - Pasientens rekvisisjoner v0.1.7

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organization Id Type CS**

## CodeSystem: Organization Id Type CS 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/ParekIG/CodeSystem/organization-id-type-cs | *Version*:0.1.7 |
| Draft as of 2026-04-16 | *Computable Name*:OrganizationIdType_CS |

 
Id types used to identify organizations. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [OrganizationIdType_VS](ValueSet-organization-id-type-vs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "organization-id-type-cs",
  "url" : "http://hl7.no/fhir/ig/ParekIG/CodeSystem/organization-id-type-cs",
  "version" : "0.1.7",
  "name" : "OrganizationIdType_CS",
  "title" : "Organization Id Type CS",
  "status" : "draft",
  "date" : "2026-04-16T08:13:22+00:00",
  "publisher" : "Norsk helsenett - NHN",
  "contact" : [{
    "name" : "Norsk helsenett - NHN",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.nhn.no"
    }]
  }],
  "description" : "Id types used to identify organizations.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NO",
      "display" : "Norway"
    }]
  }],
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "urn:oid:2.16.578.1.12.4.1.2",
    "display" : "HER",
    "definition" : "HER-id"
  },
  {
    "code" : "urn:oid:2.16.578.1.12.4.1.4.101",
    "display" : "ENH",
    "definition" : "Enhetsregisteret - Brønnøysund"
  },
  {
    "code" : "urn:oid:2.16.578.1.12.4.1.4.102",
    "display" : "RESH",
    "definition" : "enheter i spesialisthelsetjenesten"
  }]
}

```
