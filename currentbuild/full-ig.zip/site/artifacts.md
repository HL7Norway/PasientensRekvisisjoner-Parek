# Artifacts Summary - Pasientens rekvisisjoner v0.1.7

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Abstract Profiles 

These are profiles on resources or data types that describe patterns used by other profiles, but cannot be instantiated directly. I.e. instances can conform to profiles **based** on these abstract profiles but do not declare conformance to the abstract profiles themselves.

| | |
| :--- | :--- |
| [ParekPractitionerRole](StructureDefinition-parek-practitioner-role.md) | PractitionerRole as used in Parek. Used to combine actors of type Practitioner and Organization. Practitioner and Organization are referenced by their Identifier. This is an 'abstract' base profile for ParekRequester and ParekCollector. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Parek Device](StructureDefinition-parek-device.md) | Device as used in Parek. |
| [ParekCollector](StructureDefinition-parek-collector-pr.md) |  |
| [ParekRequester](StructureDefinition-parek-requester-pr.md) |  |
| [ParekServiceRequest](StructureDefinition-parek-service-request.md) | ServiceRecuest as used in Parek. |
| [ParekSpecimen](StructureDefinition-parek-specimen.md) | Specimen as used in Parek. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Organization Id Type VS](ValueSet-organization-id-type-vs.md) | Id types for organizations involved in DiagnosticReport/Observation |
| [Person Id Type VS](ValueSet-healthcare-person-id-type-vs.md) | Id types used to identify persons involved, other than the patient. |
| [Public Id Type VS](ValueSet-person-public-id-type-vs.md) | Id types used to identify patients |
| [Specimen Type VS](ValueSet-specimen-type-vs.md) | Type og material in specimen. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Healthcare Person Id Type CS](CodeSystem-healthcare-person-id-type-cs.md) | Id types used to identify healthcare persons. |
| [Organization Id Type CS](CodeSystem-organization-id-type-cs.md) | Id types used to identify organizations. |
| [Person Public Id Type CS](CodeSystem-person-public-id-type-cs.md) | Public id types used to identify persons. |

### Terminology: Naming Systems 

These define identifier and/or code system identities used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [RequesterDefinedUuid](NamingSystem-RequesterDefinedUuid.md) | NamingSystem for a required identifier that must be unique. Provides idempotency in case client systems tries to create same resource twice. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [A Device](Device-ADevice.md) | Example of a device |
| [A Request](ServiceRequest-ARequest.md) | Example of ParekServiceRequest |
| [A Specimen](Specimen-ASpecimen.md) | Example of ParekSpecimen |
| [Parek Collector](PractitionerRole-ACollector.md) | Example of collector with only organization |
| [Parek Requester](PractitionerRole-ARequester.md) | Example of requester with both practitioner and organization |

